chrome.action.onClicked.addListener((tab) => {
  if (!tab?.id) return;
  chrome.tabs.sendMessage(tab.id, { type: "OPEN_OVERLAY" });
});

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg?.type === "RUN_SYNC" && sender.tab?.id) {
    chrome.scripting.executeScript({
      target: { tabId: sender.tab.id },
      world: "MAIN",
      func: runSyncMutation,
      args: [msg.igId]
    });
  }
});

async function runSyncMutation(igId) {
  const createId = () =>
    ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, c =>
      (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
    );

  try {
    const token = require("DTSGInitData").token;
    const fbId = require("CurrentUserInitialData").USER_ID;

    const variables = {
      client_mutation_id: createId(),
      accounts_to_sync: [igId, fbId],
      resources_to_sync: ["NAME", "PROFILE_PHOTO"],
      resources_to_unsync: null,
      scale: 3,
      source_of_truth_array: [{ resource_source: "IG" }, { resource_source: "FB" }],
      source_account: fbId,
      family_device_id: "device_id_fetch_datr",
      username_unsync_params: null,
      platform: "FACEBOOK",
      sync_logging_params: { client_flow_type: "IM_SETTINGS" },
      interface: "FB_WEB",
      feta_profile_sync: false
    };

    const body =
      `fb_dtsg=${encodeURIComponent(token)}` +
      `&__user=${fbId}` +
      `&variables=${encodeURIComponent(JSON.stringify(variables))}` +
      `&av=${fbId}` +
      `&fb_api_req_friendly_name=useFXIMUpdateNameMutation` +
      `&fb_api_caller_class=RelayModern&server_timestamps=true&doc_id=9388416374608398`;

    const res = await fetch("https://accountscenter.facebook.com/api/graphql/", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body
    });

    const data = await res.json();

    window.postMessage(
      { source: "resultEvent", type: "SYNC_RESULT", ok: !(data.errors || data.error), data },
      "*"
    );
  } catch (e) {
    window.postMessage(
      { source: "resultEvent", type: "SYNC_RESULT", ok: false, error: String(e) },
      "*"
    );
  }
}
