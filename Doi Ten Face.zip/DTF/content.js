chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === "OPEN_OVERLAY") showOverlay();
});

function extractIDs() {
  let result = { fb: null, ig: null };

  const match = location.pathname.match(/profiles\/(\d+)/);
  if (match) {
    const id = match[1];
    const text = document.body.innerText;
    if (/Instagram/i.test(text)) result.ig = id;
    else if (/Facebook/i.test(text)) result.fb = id;
  }

  document.querySelectorAll('a[href*="/profiles/"]').forEach(a => {
    const href = a.getAttribute("href") || "";
    const m = href.match(/profiles\/(\d+)/);
    if (m) {
      if (/instagram/i.test(a.innerText)) result.ig = m[1];
      if (/facebook/i.test(a.innerText)) result.fb = m[1];
    }
  });

  return result;
}

function showOverlay() {
  const existed = document.getElementById("overlay");
  if (existed) existed.remove();

  const overlay = document.createElement("div");
  overlay.id = "overlay";
  overlay.style.cssText =
    "position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:2147483647;" +
    "display:flex;align-items:center;justify-content:center;animation:fadeIn .25s ease;";

  const style = document.createElement("style");
  style.textContent =
    "@keyframes fadeIn{from{opacity:0}to{opacity:1}}" +
    "@keyframes slideUp{from{transform:translateY(30px);opacity:0}" +
    "to{transform:translateY(0);opacity:1}}";
  document.head.appendChild(style);

  const overlayBox = document.createElement("div");
  overlayBox.style.cssText =
    "background:#222;color:white;margin-right:20px;width:calc(100% - 20px);" +
    "border:1px solid #555;border-radius:8px;max-width:420px;" +
    "box-shadow:0 12px 28px rgba(0,0,0,.2);font-family:Segoe UI,Helvetica,Arial,sans-serif;" +
    "animation:slideUp .25s ease;overflow:hidden;";

  const header = document.createElement("div");
  header.style.cssText =
    "padding:12px 16px;border-bottom:1px solid #dddfe2;font-size:15px;" +
    "font-weight:600;display:flex;justify-content:space-between;align-items:center;";
  header.innerHTML = '<span style="font-weight:bold;color:white;">TOOL ĐỔI TÊN ICON FACEBOOK</span>';

  const closeBtn = document.createElement("span");
  closeBtn.textContent = "✕";
  closeBtn.style.cssText = "cursor:pointer;font-size:18px;";
  closeBtn.onclick = () => overlay.remove();
  header.appendChild(closeBtn);

  const body = document.createElement("div");
  body.style.cssText = "padding:16px;";

  const statusWrap = document.createElement("div");
  statusWrap.style.cssText = "display:flex;flex-direction:column;gap:4px;font-size:14px;margin-bottom:6px;font-weight:500;";

  const statusText = document.createElement("span");
  statusText.id = "statusText";
  statusText.textContent = "Đang tự động lấy ID...";
  statusWrap.appendChild(statusText);

  body.appendChild(statusWrap);

  const messageBox = document.createElement("div");
  messageBox.id = "messageBox";
  messageBox.style.cssText = "margin-top:8px;font-size:13px;color:#ccc;";
  body.appendChild(messageBox);

  const footer = document.createElement("div");
  footer.style.cssText =
    "padding:12px 16px;border-top:1px solid #dddfe2;display:flex;justify-content:flex-end;gap:8px;";

  const cancelBtn = document.createElement("button");
  cancelBtn.textContent = "Hủy";
  cancelBtn.style.cssText =
    "padding:6px 16px;border:1px solid #ccd0d5;border-radius:6px;background:black;color:white;cursor:pointer;font-size:14px;";
  cancelBtn.onclick = () => overlay.remove();

  const okBtn = document.createElement("button");
  okBtn.textContent = "OK";
  okBtn.style.cssText =
    "padding:6px 16px;border:none;border-radius:6px;background:#1877f2;color:#fff;" +
    "cursor:pointer;font-size:14px;font-weight:600;";
  okBtn.onclick = () => {
    const igId = overlay.dataset.igId || "";
    const fbId = overlay.dataset.fbId || "";

    if (!igId && !fbId) {
      messageBox.style.color = "#d93025";
      messageBox.textContent = "Không tìm thấy ID để gửi.";
      return;
    }

    messageBox.style.color = "#ccc";
    messageBox.textContent = "Đang gửi yêu cầu...";
    chrome.runtime.sendMessage({ type: "RUN_SYNC", igId, fbId });
  };

  footer.appendChild(cancelBtn);
  footer.appendChild(okBtn);

  overlayBox.appendChild(header);
  overlayBox.appendChild(body);
  overlayBox.appendChild(footer);
  overlay.appendChild(overlayBox);
  document.documentElement.appendChild(overlay);

  const ids = extractIDs();
  let lines = [];

  if (ids.ig) {
    overlay.dataset.igId = ids.ig;
    lines.push("✅ Instagram ID: " + ids.ig);
  }
  if (ids.fb) {
    overlay.dataset.fbId = ids.fb;
    lines.push("✅ Facebook ID: " + ids.fb);
  }

  statusText.innerHTML =
    lines.length > 0 ? lines.join("<br>") : "❌ Không tìm thấy ID.";
}

document.addEventListener("click", (e) => {
  if (e.target?.textContent?.trim().toLowerCase() === "ok") {
    setTimeout(() => location.reload(), 3000);
  }
});
